package relateInterface;

public interface OrderManger {
	public String selectByNumber(String ordernumber);
}
