package relateInterface;

public interface Search {
    public String searchFuzzy(String keyword);//模糊搜索
    public String listHotProviders();//获得推荐商家列表
}
